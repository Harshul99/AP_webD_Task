
function rolll() {
    const imgPack = ["images/dice1.png","images/dice2.png","images/dice3.png","images/dice4.png","images/dice5.png","images/dice6.png"]; 
    var roller1= Math.floor(Math.random() * 6);
    var roller2= Math.floor(Math.random() * 6);
    //note imgPack[roller1] is not inside quotes  
    //part 1
    document.querySelector(".img1").setAttribute("src",imgPack[roller1]);
    document.querySelector(".img2").setAttribute("src",imgPack[roller2]); 
    //part 2
    // if(roller1 > roller2){
    //     document.querySelector(".container").innerHTML="<h1>Player 1 wins</h1>";
    // }
    // else if(roller1 < roller2){
    //     document.querySelector(".container").innerHTML="<h1>Player 2 wins</h1>";
    // }
    // else{
    //     document.querySelector(".container").innerHTML="<h1>Draw</h1>";
    // }  

   
    document.querySelector(".img1").setAttribute("src",imgPack[roller1]);
    document.querySelector(".img2").setAttribute("src",imgPack[roller2]); 
}
rolll();
//doubt when I am running this code than part 1 is not exicuting, part one only excutes when I comment out part 2